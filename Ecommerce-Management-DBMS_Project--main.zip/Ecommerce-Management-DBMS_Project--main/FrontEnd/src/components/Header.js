import React from 'react'

const Header = () => {
    const headerStyle ={
        
    }
  return (
    <div>Header</div>
  )
}

export default Header