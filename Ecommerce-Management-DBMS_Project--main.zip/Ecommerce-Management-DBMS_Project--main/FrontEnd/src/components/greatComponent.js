import React from 'react'

const greatComponent = (props) => {
  return (
    <div>
        {props.name}
    </div>
  )
}



export default greatComponent