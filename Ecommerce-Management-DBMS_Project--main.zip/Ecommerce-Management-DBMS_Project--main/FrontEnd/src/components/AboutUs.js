import React from 'react'

export const AboutUs = () => {
  return (
    <div>AboutUs</div>
  )
}
