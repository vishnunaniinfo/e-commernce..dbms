import {createContext} from 'react';

export const nameContext = createContext();